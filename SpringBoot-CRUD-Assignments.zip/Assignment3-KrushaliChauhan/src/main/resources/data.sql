-- Insert Course Categories
INSERT INTO COURSE_CATEGORIES (CATEGORY_ID, CATEGORY_NAME) VALUES (1, 'Technology');
INSERT INTO COURSE_CATEGORIES (CATEGORY_ID, CATEGORY_NAME) VALUES (2, 'Business');
INSERT INTO COURSE_CATEGORIES (CATEGORY_ID, CATEGORY_NAME) VALUES (3, 'Health & Fitness');

-- Insert Courses
INSERT INTO COURSES (COURSE_ID, COURSE_TITLE, CATEGORY, INSTRUCTOR, PRICE, DURATION, PLATFORM, DESCRIPTION)
VALUES (2001, 'Java Programming', 'Technology', 'John Doe', 99.99, 15.5, 'Udemy', 'Comprehensive Java course.');

INSERT INTO COURSES (COURSE_ID, COURSE_TITLE, CATEGORY, INSTRUCTOR, PRICE, DURATION, PLATFORM, DESCRIPTION)
VALUES (2002, 'Digital Marketing Basics', 'Business', 'Jane Smith', 79.99, 12.0, 'Coursera', 'Intro to digital marketing.');

INSERT INTO COURSES (COURSE_ID, COURSE_TITLE, CATEGORY, INSTRUCTOR, PRICE, DURATION, PLATFORM, DESCRIPTION)
VALUES (2003, 'Yoga for Beginners', 'Health & Fitness', 'Arjun Patel', 59.99, 8.0, 'YouTube', 'Start your yoga journey.');

INSERT INTO sec_role (roleName) VALUES ('ROLE_USER');
INSERT INTO sec_role (roleName) VALUES ('ROLE_ADMIN');

INSERT INTO sec_user (email, encryptedPassword, enabled) 
VALUES ('pooja.kakkar@sheridancollege.ca', '$2y$10$UtQcujoSABQJuq5pk5bsIOzLINxzFYt0O/dopQrNeY4I17dJiV2ze', 1);

INSERT INTO sec_user (email, encryptedPassword, enabled) 
VALUES ('krushali@sheridancollege.ca', '$2y$10$f5u.kJbuN.0r2ukk6GZlAuJ4BthIISkwXzrzKE/brUcmWHLdHp2tO', 1);

INSERT INTO user_role (userId, roleId) VALUES (1, 2); 
INSERT INTO user_role (userId, roleId) VALUES (2, 2); 