package ca.sheridancollege.chaukrus.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Course {
	private int courseId;
    private String courseTitle;
    private String category;
    private String instructor;
    private double price;
    private double duration;
    private String platform;
    private String description;
}
