package ca.sheridancollege.chaukrus.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private NamedParameterJdbcTemplate jdbc;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String userQuery = "SELECT userId, email, encryptedPassword, enabled FROM sec_user WHERE email = :email";
        MapSqlParameterSource userParams = new MapSqlParameterSource();
        userParams.addValue("email", username);

        List<Map<String, Object>> users = jdbc.queryForList(userQuery, userParams);
        if (users.isEmpty()) {
            throw new UsernameNotFoundException("User not found: " + username);
        }

        Map<String, Object> userRow = users.get(0);
        Long userId = ((Number) userRow.get("userId")).longValue();
        String encryptedPassword = (String) userRow.get("encryptedPassword");
        Boolean enabled = (Boolean) userRow.get("enabled");

        String rolesQuery = """
                SELECT r.roleName
                  FROM sec_role r
                  JOIN user_role ur ON r.roleId = ur.roleId
                 WHERE ur.userId = :userId
                """;
        MapSqlParameterSource roleParams = new MapSqlParameterSource();
        roleParams.addValue("userId", userId);
        List<String> roleNames = jdbc.queryForList(rolesQuery, roleParams, String.class);

        List<GrantedAuthority> authorities = new ArrayList<>();
        for (String role : roleNames) {
            if (!role.startsWith("ROLE_")) {
                role = "ROLE_" + role;
            }
            authorities.add(new SimpleGrantedAuthority(role));
        }

        return org.springframework.security.core.userdetails.User.builder()
                .username((String) userRow.get("email"))
                .password(encryptedPassword)
                .authorities(authorities)
                .disabled(!enabled)
                .build();
    }
}
