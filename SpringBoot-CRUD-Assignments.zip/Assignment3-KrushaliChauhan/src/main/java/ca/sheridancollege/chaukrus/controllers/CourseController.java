package ca.sheridancollege.chaukrus.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import ca.sheridancollege.chaukrus.beans.Course;
import ca.sheridancollege.chaukrus.beans.User;
import ca.sheridancollege.chaukrus.database.DatabaseAccess;

@Controller
public class CourseController {

    @Autowired
    private DatabaseAccess da;

    @GetMapping("/")
    public String publicIndex() {
        return "index";
    }

    @GetMapping("/docs")
    public String docs() {
        return "redirect:/doc/index.html";  
    }
    
    @GetMapping("/secure")
    public String secureDashboard(Model model, Authentication authentication) {
        String email = authentication.getName();
        model.addAttribute("email", email);
        return "secure/index";
    }

    @GetMapping("/insert")
    public String showInsertForm(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("categories", da.getAllCategoryNames());
        return "secure/insert";
    }

    @PostMapping("/insert")
    public String doInsert(@ModelAttribute Course course, Model model) {
        da.insertProduct(course);
        model.addAttribute("course", new Course());
        model.addAttribute("categories", da.getAllCategoryNames());
        model.addAttribute("message", "Course inserted.");
        return "secure/insert";
    }

    @GetMapping("/update")
    public String showUpdateForm(Model model) {
        model.addAttribute("courses", da.getAllProduct());
        return "secure/update";
    }

    @PostMapping("/update")
    public String doUpdatePrice(@RequestParam int courseId, @RequestParam double price, Model model) {
        da.updateProduct(courseId, price);
        model.addAttribute("courses", da.getAllProduct());
        model.addAttribute("message", "Course price updated.");
        return "secure/update";
    }

    @GetMapping("/delete")
    public String showDeleteForm(Model model) {
        model.addAttribute("courses", da.getAllProduct());
        return "secure/delete";
    }

    @PostMapping("/delete")
    public String doDelete(@RequestParam int courseId, Model model) {
        da.deleteProduct(courseId);
        model.addAttribute("courses", da.getAllProduct());
        model.addAttribute("message", "Course deleted.");
        return "secure/delete";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String getRegister() {
        return "register";
    }

    @PostMapping("/register")
    public String postRegister(@RequestParam("username") String email,
                               @RequestParam String password,
                               @RequestParam String verifyPassword,
                               Model model) {
        email = email.trim();
        if (!password.equals(verifyPassword)) {
            model.addAttribute("errorMessage", "Passwords do not match.");
            return "register";
        }
        User existing = da.findUserAccount(email);
        if (existing != null) {
            model.addAttribute("errorMessage", "Email is already registered.");
            return "register";
        }
        da.addUser(email, password);
        Long userId = da.findUserAccount(email).getUserId();
        da.addRole(userId, 1L);
        return "redirect:/login?registered";
    }

    @GetMapping("/permission-denied")
    public String permissionDenied() {
        return "error/permission-denied";
    }
}
