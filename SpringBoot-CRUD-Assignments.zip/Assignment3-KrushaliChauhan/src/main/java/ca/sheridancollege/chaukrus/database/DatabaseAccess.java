package ca.sheridancollege.chaukrus.database;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.chaukrus.beans.Course;
import ca.sheridancollege.chaukrus.beans.User;

@Repository
public class DatabaseAccess {

    @Autowired
    protected NamedParameterJdbcTemplate jdbc;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ======== USER / ROLE METHODS ========

    public User findUserAccount(String email) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "SELECT * FROM sec_user WHERE email = :email";
        params.addValue("email", email);
        try {
            return jdbc.queryForObject(query, params, new BeanPropertyRowMapper<>(User.class));
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public List<String> getRolesById(Long userId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "SELECT sec_role.roleName " +
                       "FROM user_role, sec_role " +
                       "WHERE user_role.roleId = sec_role.roleId " +
                       "AND userId = :userId";
        params.addValue("userId", userId);
        return jdbc.queryForList(query, params, String.class);
    }

    public void addUser(String email, String password) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "INSERT INTO sec_user (email, encryptedPassword, enabled) " +
                       "VALUES (:email, :encryptedPassword, 1)";
        params.addValue("email", email);
        params.addValue("encryptedPassword", passwordEncoder.encode(password));
        jdbc.update(query, params);
    }

    public void addRole(Long userId, Long roleId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "INSERT INTO user_role (userId, roleId) VALUES (:userId, :roleId)";
        params.addValue("userId", userId);
        params.addValue("roleId", roleId);
        jdbc.update(query, params);
    }

    // ======== COURSE METHODS ========

    public void insertProduct(Course course) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "INSERT INTO COURSES (COURSE_ID, COURSE_TITLE, CATEGORY, INSTRUCTOR, PRICE, DURATION, PLATFORM, DESCRIPTION) "
                     + "VALUES (:courseId, :courseTitle, :category, :instructor, :price, :duration, :platform, :description)";

        params.addValue("courseId", course.getCourseId());
        params.addValue("courseTitle", course.getCourseTitle());
        params.addValue("category", course.getCategory());
        params.addValue("instructor", course.getInstructor());
        params.addValue("price", course.getPrice());
        params.addValue("duration", course.getDuration());
        params.addValue("platform", course.getPlatform());
        params.addValue("description", course.getDescription());

        jdbc.update(query, params);
    }

    public void updateProduct(int courseId, double price) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "UPDATE COURSES SET PRICE = :price WHERE COURSE_ID = :courseId";
        params.addValue("price", price);
        params.addValue("courseId", courseId);
        jdbc.update(query, params);
    }

    public void deleteProduct(int courseId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "DELETE FROM COURSES WHERE COURSE_ID = :courseId";
        params.addValue("courseId", courseId);
        jdbc.update(query, params);
    }

    public List<Course> getAllProduct() {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "SELECT * FROM COURSES ORDER BY COURSE_ID";
        return jdbc.query(query, params, new BeanPropertyRowMapper<>(Course.class));
    }

    public Course getProductById(int courseId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "SELECT * FROM COURSES WHERE COURSE_ID = :courseId";
        params.addValue("courseId", courseId);
        List<Course> results = jdbc.query(query, params, new BeanPropertyRowMapper<>(Course.class));
        return results.isEmpty() ? null : results.get(0);
    }

    public List<String> getAllCategoryNames() {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String query = "SELECT CATEGORY_NAME FROM COURSE_CATEGORIES ORDER BY CATEGORY_NAME";
        return jdbc.queryForList(query, params, String.class);
    }
}
