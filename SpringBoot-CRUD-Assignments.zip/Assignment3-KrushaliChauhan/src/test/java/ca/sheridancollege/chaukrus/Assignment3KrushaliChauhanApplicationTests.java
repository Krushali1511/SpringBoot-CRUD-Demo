package ca.sheridancollege.chaukrus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment3KrushaliChauhanApplicationTests {

	@Test
	void contextLoads() {
	}

}
